//
//  ViewController.swift
//  Dicee
//
//  Created by Олжас Айдархан on 20.07.2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var rollButton: UIButton!
    @IBOutlet weak var diceOneImageView: UIImageView!
    @IBOutlet weak var diceTwoImageView: UIImageView!
    
    private var images: [String] = [ "dice1", "dice2", "dice3", "dice4", "dice5", "dice6"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        rollButton.layer.cornerRadius = 4
        rollButton.layer.masksToBounds = true
        
        
    }

    @IBAction func rollButtonPressed(_ sender: Any) {
        
        let random1: Int = Int(arc4random()) % 6
        let random2: Int = Int(arc4random()) % 6
        
        
        diceOneImageView.image = UIImage(named: images[random1] )
        diceTwoImageView.image = UIImage(named: images[random2])
    }
    
}

